Name: Shengyang Xu
Assignment P0 for Web Lab

-------Notes for my program-----------
I did not write any html in p0.html, so testing p0.js is somewhat messy - you might need to go into the file and manually change the arguments for testing.

-------Online Resources Used----------
http://www.w3schools.com/jsref/  
	This is for js specific questions, for instance the function string.charAt().

http://www.mapbender.org/JavaScript_pitfalls:_null,_false,_undefined,_NaN   
	Browsed this site for some easily confusing terminologies in JS. (especially NaN, null and undefined)
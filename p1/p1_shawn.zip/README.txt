Received great help from two Stackoverflow posts:

Color changing function: http://stackoverflow.com/questions/5560248/programmatically-lighten-or-darken-a-hex-color-or-rgb-and-blend-colors

Get the size of the background image, so as to determine the appropriate width and height for each tile. With reference to http://stackoverflow.com/questions/3098404/get-the-size-of-a-css-background-image-using-javascript